<!DOCTYPE html>
<html lang="fr">
<?php
require_once __DIR__ . '/../../enums/chemin_page.php';
use App\Enums\CheminPage;
$url = "http://" . $_SERVER["HTTP_HOST"];
$css_path = CheminPage::CSS_AJOUT_APPRENANT->value;
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Importer des Apprenants</title>
    <link rel="stylesheet" href="<?= $url . $css_path ?>">
    <style>
        .error-message {
            color: #e74c3c;
            font-size: 0.9em;
            margin-top: 5px;
            display: block;
        }

        input.error, select.error {
            border: 1px solid #e74c3c;
        }
        
        .alert {
            padding: 10px 15px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        
        .alert-warning {
            background-color: #fcf8e3;
            border: 1px solid #faebcc;
            color: #8a6d3b;
        }
        
        .error-list {
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #eee;
            padding: 10px;
            margin-top: 10px;
            background-color: #f9f9f9;
        }
        
        .template-download {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Content Area -->
    <div class="content">
        <div class="form-container">
            <h2>Importer des apprenants</h2>
            
            <!-- Affichage des erreurs générales s'il y en a -->
            <?php if (isset($erreurs['general'])): ?>
                <div class="error-message"><?= $erreurs['general'] ?></div>
                
                <?php if (isset($erreurs['details']) && !empty($erreurs['details'])): ?>
                    <div class="error-list">
                        <ul>
                            <?php foreach ($erreurs['details'] as $message): ?>
                                <li><?= htmlspecialchars($message) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            
            <div class="template-download">
                <p>Téléchargez notre modèle de fichier Excel pour l'importation:</p>
                <a href="assets/templates/modele_import_apprenants.xlsx" class="btn-submit" download>Télécharger le modèle</a>
            </div>
            
            <form action="index.php?page=traiter_import_excel" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="fichier_excel">Fichier Excel (.xlsx, .xls) ou CSV</label>
                    <input type="file" id="fichier_excel" name="fichier_excel" accept=".xlsx,.xls,.csv" class="<?= isset($erreurs['fichier']) ? 'error' : '' ?>">
                    <?php if (isset($erreurs['fichier'])): ?>
                        <span class="error-message"><?= $erreurs['fichier'] ?></span>
                    <?php endif; ?>
                    <small>Le fichier doit contenir les colonnes suivantes: Prénom, Nom, Date de naissance, Lieu de naissance, Adresse, Email, Téléphone, Référentiel, Nom du tuteur, Lien de parenté, Adresse du tuteur, Téléphone du tuteur</small>
                </div>
                
                <div class="form-buttons">
                    <button type="submit" class="btn-submit">Importer</button>
                    <a href="index.php?page=apprenant" class="btn-cancel">Annuler</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>


<div class="container-fluid">
    <div class="row page-titles">
        <div class="col-md-12 align-self-center">
            <h4 class="text-themecolor">Importer des apprenants</h4>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php if (isset($erreurs['general'])): ?>
                        <div class="alert alert-danger">
                            <?= $erreurs['general'] ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($erreurs['details']) && is_array($erreurs['details'])): ?>
                        <div class="alert alert-warning">
                            <h5>Détails des erreurs:</h5>
                            <ul>
                                <?php foreach ($erreurs['details'] as $message): ?>
                                    <li><?= $message ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <form action="index.php?page=traiter_import_excel" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label class="control-label mb-3">Téléchargez notre modèle de fichier Excel pour l'importation:</label>
                            <div class="mb-4">
                                <a href="assets/templates/modele_import_apprenants.xlsx" class="btn btn-info" download>
                                    <i class="fa fa-download"></i> Télécharger le modèle
                                </a>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="fichier_excel">Fichier Excel (.xlsx, .xls) ou CSV</label>
                            <input type="file" name="fichier_excel" id="fichier_excel" class="form-control <?= isset($erreurs['fichier']) ? 'is-invalid' : '' ?>">
                            <?php if (isset($erreurs['fichier'])): ?>
                                <div class="invalid-feedback"><?= $erreurs['fichier'] ?></div>
                            <?php endif; ?>
                            <small class="form-text text-muted">
                                Le fichier doit contenir les colonnes suivantes: Prénom, Nom, Date de naissance, Lieu de naissance, Adresse, Email, Téléphone, Référentiel, Nom du tuteur, Lien de parenté, Adresse du tuteur, Téléphone du tuteur
                            </small>
                            <small class="form-text text-warning mt-2">
                                <i class="fa fa-info-circle"></i> Les apprenants avec des emails déjà existants dans le système seront ignorés pour éviter les doublons.
                            </small>
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-upload"></i> Importer
                            </button>
                            <a href="index.php?page=apprenant" class="btn btn-secondary">Annuler</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
